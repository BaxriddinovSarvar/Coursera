import React from "react";
import { Avatar, Heading, Text, VStack } from "@chakra-ui/react";
import FullScreenSection from "./FullScreenSection";
import avatarImg from "../images/avatar.jpg";

const greeting = "Hello, I am Pete!";
const bio1 = "A frontend developer";
const bio2 = "specialised in React";

// Implement the UI for the LandingSection component according to the instructions.
// Use a combination of Avatar, Heading and VStack components.
const LandingSection = () => (
  <FullScreenSection
    justifyContent="center"
    alignItems="center"
    isDarkBackground
    backgroundColor="#2A4365"
  >
    <VStack>
      <Avatar
        size="xl"
        name="Norma Angelica Maria Tovar"
        src={avatarImg}
      ></Avatar>
      <Text fontSize="md" as="b">
        Hello! I'm Angelica
      </Text>
      <Heading as="h2" size="2xl" textAlign={["center"]}>
        A frontend developer specialised in React
      </Heading>
    </VStack>
  </FullScreenSection>
);

export default LandingSection;
