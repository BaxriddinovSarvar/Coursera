import {
  Heading,
  Stack,
  Image,
  Text,
  CardBody,
  CardFooter,
} from "@chakra-ui/react";
import { Card as ChakraCard } from "@chakra-ui/react";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowRight } from "@fortawesome/free-solid-svg-icons";
import React from "react";

const Card = ({ title, description, imageSrc }) => {
  return (
    <ChakraCard maxW="sm">
      <Image
        src={imageSrc}
        alt={title}
        borderRadius="inherit"
        objectFit="cover"
      />
      <CardBody>
        <Stack mt="6" spacing="3">
          <Heading size="md">{title}</Heading>
          <Text>{description}</Text>
        </Stack>
      </CardBody>
      <CardFooter>
        <a href="">
          <Text as="b">
            See more <FontAwesomeIcon icon={faArrowRight} size="1x" />
          </Text>
        </a>
      </CardFooter>
    </ChakraCard>
  );
};

export default Card;
